import React, { useState } from 'react';
import { UserProfile } from '../types';
import { 
  Lock, 
  User, 
  KeyRound, 
  CheckCircle2, 
  Crown, 
  Sparkles, 
  AlertCircle,
  Eye,
  EyeOff,
  ShieldCheck,
  Utensils
} from 'lucide-react';

interface AuthGateModalProps {
  onLoginSuccess: (user: UserProfile) => void;
}

export const AuthGateModal: React.FC<AuthGateModalProps> = ({ onLoginSuccess }) => {
  const [isRegisterMode, setIsRegisterMode] = useState(true);
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isRoyalSignup, setIsRoyalSignup] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const cleanUsername = username.trim();
    const cleanDisplayName = displayName.trim() || cleanUsername;

    if (!cleanUsername) {
      setErrorMessage('กรุณากรอกชื่อผู้ใช้งาน (Username)');
      return;
    }

    if (!password) {
      setErrorMessage('กรุณากรอกรหัสผ่าน');
      return;
    }

    if (password.length < 4) {
      setErrorMessage('รหัสผ่านต้องมีความยาวอย่างน้อย 4 ตัวอักษร');
      return;
    }

    if (password !== confirmPassword) {
      setErrorMessage('รหัสผ่านและยืนยันรหัสผ่านไม่ตรงกัน กรุณาตรวจสอบอีกครั้ง');
      return;
    }

    // Check if account already exists
    const accountsJson = localStorage.getItem('menu100_accounts');
    const accounts = accountsJson ? JSON.parse(accountsJson) : [];
    
    const existing = accounts.find((a: any) => a.username.toLowerCase() === cleanUsername.toLowerCase());
    if (existing) {
      setErrorMessage('ชื่อผู้ใช้นี้มีคนใช้แล้ว กรุณาใช้ชื่ออื่น หรือสลับไปแท็บเข้าสู่ระบบ');
      return;
    }

    const newAccount = {
      username: cleanUsername,
      displayName: cleanDisplayName,
      passwordHash: password, // client demo persistence
      isRoyal: isRoyalSignup,
      role: cleanUsername.toLowerCase() === 'admin' ? 'admin' : 'user',
      createdAt: new Date().toLocaleDateString('th-TH'),
    };

    accounts.push(newAccount);
    localStorage.setItem('menu100_accounts', JSON.stringify(accounts));

    const newUserProfile: UserProfile = {
      id: `usr-${cleanUsername.toLowerCase()}`,
      username: cleanUsername,
      name: cleanDisplayName,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
      isRoyal: isRoyalSignup,
      royalLevel: isRoyalSignup ? 'Diamond' : 'Gold',
      role: newAccount.role as 'user' | 'admin',
      joinedDate: 'กันยายน 2026',
      votedFoodIds: [],
      bookmarkedRestaurantIds: [],
      royalVotesLeftThisMonth: 10,
    };

    onLoginSuccess(newUserProfile);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const cleanUsername = username.trim();
    if (!cleanUsername || !password) {
      setErrorMessage('กรุณากรอกชื่อผู้ใช้และรหัสผ่านให้ครบถ้วน');
      return;
    }

    const accountsJson = localStorage.getItem('menu100_accounts');
    const accounts = accountsJson ? JSON.parse(accountsJson) : [];

    const account = accounts.find((a: any) => a.username.toLowerCase() === cleanUsername.toLowerCase());
    if (!account) {
      setErrorMessage('ไม่พบชื่อผู้ใช้งานนี้ในระบบ กรุณาสมัครสมาชิกก่อน');
      return;
    }

    if (account.passwordHash !== password) {
      setErrorMessage('รหัสผ่านไม่ถูกต้อง กรุณาลองใหม่อีกครั้ง');
      return;
    }

    const loggedUser: UserProfile = {
      id: `usr-${account.username.toLowerCase()}`,
      username: account.username,
      name: account.displayName || account.username,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
      isRoyal: account.isRoyal ?? true,
      royalLevel: account.isRoyal ? 'Diamond' : 'Gold',
      role: account.role || 'user',
      joinedDate: account.createdAt || 'กันยายน 2026',
      votedFoodIds: [],
      bookmarkedRestaurantIds: [],
      royalVotesLeftThisMonth: 10,
    };

    onLoginSuccess(loggedUser);
  };

  // Quick preset login for seamless review
  const handleQuickEnter = (role: 'foodie' | 'admin') => {
    const isAdm = role === 'admin';
    const profile: UserProfile = {
      id: isAdm ? 'usr-admin-01' : 'usr-foodie-demo',
      username: isAdm ? 'admin' : 'foodie_lover',
      name: isAdm ? 'ผู้ดูแลระบบ menu100 (Admin)' : 'นักชิมสายกินจุ (Foodie Pass)',
      avatar: isAdm
        ? 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'
        : 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
      isRoyal: true,
      royalLevel: 'Diamond',
      role: isAdm ? 'admin' : 'user',
      joinedDate: 'กันยายน 2026',
      votedFoodIds: [],
      bookmarkedRestaurantIds: [],
      royalVotesLeftThisMonth: 10,
    };
    onLoginSuccess(profile);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="w-full max-w-md bg-white rounded-3xl overflow-hidden shadow-2xl border border-amber-500/30 my-8">
        {/* Modal Top Banner */}
        <div className="bg-gradient-to-br from-slate-900 via-stone-900 to-amber-950 p-6 text-white text-center relative border-b border-amber-500/30">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center text-white font-black text-2xl shadow-lg mb-3">
            m100
          </div>
          <h2 className="text-2xl font-black tracking-tight text-white">
            ยินดีต้อนรับสู่ <span className="text-amber-400">menu100</span>
          </h2>
          <p className="text-xs text-slate-300 mt-1">
            กรุณาสมัครไอดีหรือเข้าสู่ระบบ เพื่อร่วมโหวตอาหารและใช้งานเว็บไซต์
          </p>

          {/* Mode Switch Tabs */}
          <div className="grid grid-cols-2 gap-2 mt-5 p-1 bg-white/10 rounded-2xl border border-white/10">
            <button
              id="auth-tab-register"
              type="button"
              onClick={() => {
                setIsRegisterMode(true);
                setErrorMessage(null);
              }}
              className={`py-2 text-xs font-bold rounded-xl transition-all ${
                isRegisterMode
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              สมัครไอดีใหม่ (Register)
            </button>
            <button
              id="auth-tab-login"
              type="button"
              onClick={() => {
                setIsRegisterMode(false);
                setErrorMessage(null);
              }}
              className={`py-2 text-xs font-bold rounded-xl transition-all ${
                !isRegisterMode
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              เข้าสู่ระบบ (Login)
            </button>
          </div>
        </div>

        {/* Form Body */}
        <div className="p-6">
          {errorMessage && (
            <div className="mb-4 p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
              <span>{errorMessage}</span>
            </div>
          )}

          {isRegisterMode ? (
            /* Register Form */
            <form onSubmit={handleRegister} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ชื่อผู้ใช้งาน (Username) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    id="register-input-username"
                    type="text"
                    required
                    placeholder="เช่น somchai_foodie"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full pl-9 pr-4 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-orange-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ชื่อเล่น / ชื่อที่ใช้แสดงในเว็บ
                </label>
                <input
                  id="register-input-display-name"
                  type="text"
                  placeholder="เช่น สมชาย สายกินเนื้อ"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-orange-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  รหัสผ่าน (Password) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    id="register-input-password"
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="รหัสผ่านอย่างน้อย 4 ตัวอักษร"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-9 pr-10 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-orange-500 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ยืนยันรหัสผ่าน (Confirm Password) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    id="register-input-confirm-password"
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="พิมพ์รหัสผ่านอีกครั้งให้ตรงกัน"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full pl-9 pr-10 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-orange-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Royal Member Perks Selection */}
              <div 
                onClick={() => setIsRoyalSignup(!isRoyalSignup)}
                className="p-3 rounded-2xl bg-amber-50/80 border border-amber-300 cursor-pointer flex items-center justify-between hover:bg-amber-100/70 transition-colors"
              >
                <div className="flex items-center gap-2.5">
                  <Crown className="w-5 h-5 text-amber-600 fill-amber-300 shrink-0" />
                  <div>
                    <span className="text-xs font-black text-amber-950 block">
                      รับสิทธิ์ Royal Member 👑 ทันที (ฟรี)
                    </span>
                    <span className="text-[11px] text-amber-800">
                      ได้คะแนนโหวต Royal Vote (x2) และสติกเกอร์ VIP ในกระทู้
                    </span>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={isRoyalSignup}
                  onChange={() => {}}
                  className="w-4 h-4 text-orange-600 rounded-md border-amber-400 focus:ring-orange-500"
                />
              </div>

              <button
                id="register-submit-btn"
                type="submit"
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-black text-xs sm:text-sm shadow-md shadow-orange-600/30 transition-transform hover:scale-102 flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>ยืนยันการสมัคร & เข้าใช้งาน menu100</span>
              </button>
            </form>
          ) : (
            /* Login Form */
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ชื่อผู้ใช้งาน (Username)
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    id="login-input-username"
                    type="text"
                    required
                    placeholder="เช่น somchai_foodie หรือ admin"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full pl-9 pr-4 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-orange-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  รหัสผ่าน (Password)
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    id="login-input-password"
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="กรอกรหัสผ่านของคุณ"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-9 pr-10 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-orange-500 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                id="login-submit-btn"
                type="submit"
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-black text-xs sm:text-sm shadow-md shadow-orange-600/30 transition-transform hover:scale-102 flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>เข้าสู่ระบบ</span>
              </button>
            </form>
          )}

          {/* Quick Demo Entrance */}
          <div className="mt-6 pt-5 border-t border-slate-200 text-center space-y-2">
            <p className="text-[11px] text-slate-500">
              หรือเข้าชมแบบรวดเร็วสำหรับการทดสอบระบบ:
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                id="auth-quick-user-btn"
                type="button"
                onClick={() => handleQuickEnter('foodie')}
                className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-[11px] font-bold border border-slate-200 transition-colors flex items-center justify-center gap-1"
              >
                <Utensils className="w-3.5 h-3.5 text-orange-600" />
                <span>เข้าเป็นสมาชิกทั่วไป</span>
              </button>
              <button
                id="auth-quick-admin-btn"
                type="button"
                onClick={() => handleQuickEnter('admin')}
                className="p-2 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-900 text-[11px] font-bold border border-amber-300 transition-colors flex items-center justify-center gap-1"
              >
                <Crown className="w-3.5 h-3.5 text-amber-700" />
                <span>เข้าเป็นแอดมินหลังบ้าน</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
