import React from 'react';
import { TabType, UserProfile } from '../types';
import { 
  Trophy, 
  MapPin, 
  ShoppingBag, 
  MessageSquare, 
  Crown, 
  Dice5, 
  Sparkles, 
  UserCheck, 
  Store,
  Sliders,
  LogOut,
  ShieldCheck,
  Download
} from 'lucide-react';


interface HeaderProps {
  currentTab: TabType;
  onSelectTab: (tab: TabType) => void;
  user: UserProfile;
  onToggleRoyal: () => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenRoulette: () => void;
  onOpenVerifyModal: () => void;
  onOpenAdmin: () => void;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  user,
  onToggleRoyal,
  cartCount,
  onOpenCart,
  onOpenRoulette,
  onOpenVerifyModal,
  onOpenAdmin,
  onLogout,
}) => {

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      {/* Top Banner: Season & Fast Royal Switch */}
      <div className="bg-gradient-to-r from-amber-600 via-orange-600 to-red-600 text-white text-xs py-1.5 px-4 font-medium">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="bg-white/20 px-2 py-0.5 rounded-full text-[11px] font-bold tracking-wide">
              SEASON 5
            </span>
            <span>⚡ รอบจัดอันดับ 2 เดือน (ก.ค. - ส.ค.) — เหลือเวลาโหวตอีก 24 วัน!</span>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {/* Direct Project ZIP Download */}
            <a
              id="header-btn-download-zip"
              href="/menu100-source.zip"
              download="menu100-source.zip"
              className="inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white border border-emerald-400/40 px-3 py-0.5 rounded-full transition-all text-[11px] font-bold shadow-xs hover:scale-102"
              title="คลิกเพื่อดาวน์โหลดไฟล์โปรเจกต์ ZIP ทั้งหมดเพื่อนำไปใส่ GitHub ทันที"
            >
              <Download className="w-3.5 h-3.5" />
              <span>📥 โหลดไฟล์โปรเจกต์ (.ZIP)</span>
            </a>

            {/* Backoffice Admin Portal Entrance */}
            <button
              id="header-btn-admin-portal"
              onClick={onOpenAdmin}
              className="inline-flex items-center gap-1.5 bg-slate-950 hover:bg-black text-amber-300 border border-amber-400/40 px-3 py-0.5 rounded-full transition-all text-[11px] font-bold shadow-xs hover:scale-102"
              title="เข้าสู่ระบบหลังบ้านเพื่ออัปเดตเมนู เปลี่ยนรูปภาพ และปรับคะแนน"
            >
              <Sliders className="w-3.5 h-3.5 text-amber-400" />
              <span>⚙️ ระบบหลังบ้าน (Backoffice)</span>
            </button>

            {/* Owner verify button shortcut */}
            <button
              id="header-btn-verify-restaurant"
              onClick={onOpenVerifyModal}
              className="hidden md:inline-flex items-center gap-1.5 bg-white/15 hover:bg-white/25 px-2.5 py-0.5 rounded-full transition-colors text-[11px]"
              title="เจ้าของร้านยื่นขอรับการตรวจสอบ 1-5 ดาว"
            >
              <Store className="w-3.5 h-3.5" />
              <span>เจ้าของร้านขอ Verify (1-5 ดาว)</span>
            </button>

            {/* Quick Demo Switcher */}
            <button
              id="header-btn-toggle-royal"
              onClick={onToggleRoyal}
              className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold transition-all ${
                user.isRoyal
                  ? 'bg-amber-300 text-amber-950 shadow-xs'
                  : 'bg-white/20 hover:bg-white/30 text-white'
              }`}
              title="กดเพื่อสลับสิทธิ์การใช้งานจำลองระหว่าง สมาชิกทั่วไป กับ Royal Member"
            >
              <Crown className="w-3.5 h-3.5" />
              <span>{user.isRoyal ? 'สถานะ: ROYAL MEMBER 👑' : 'สลับเป็น ROYAL MEMBER'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          {/* Brand Logo */}
          <div 
            onClick={() => onSelectTab('ranking')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-500 via-orange-500 to-red-500 flex items-center justify-center text-white shadow-md shadow-orange-500/20 group-hover:scale-105 transition-transform">
              <span className="font-extrabold text-xl tracking-tighter">m</span>
              <span className="font-bold text-xs bg-white text-orange-600 rounded-md px-1 py-0.5 -ml-0.5">100</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-2xl font-black tracking-tight text-slate-900 group-hover:text-orange-600 transition-colors">
                  menu<span className="text-orange-500">100</span>
                </span>
                <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-1.5 py-0.5 rounded-md border border-amber-300">
                  THAI FOOD AWARDS
                </span>
              </div>
              <p className="text-[11px] text-slate-500 hidden sm:block">
                ศูนย์รวมอันดับอาหารโลก • แผนที่ร้านเด็ด 77 จังหวัด • สังคมนักชิม
              </p>
            </div>
          </div>

          {/* Quick Actions (Roulette + Cart + Profile) */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Food Roulette Button */}
            <button
              id="header-btn-food-roulette"
              onClick={onOpenRoulette}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-orange-50 hover:bg-orange-100 text-orange-700 text-xs sm:text-sm font-semibold border border-orange-200 transition-all hover:scale-102 active:scale-98 shadow-2xs"
            >
              <Dice5 className="w-4 h-4 text-orange-600 animate-spin-slow" />
              <span className="hidden sm:inline">กินอะไรดีวันนี้?</span>
              <span className="sm:hidden">สุ่มเมนู</span>
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            </button>

            {/* Cart Button */}
            <button
              id="header-btn-cart"
              onClick={onOpenCart}
              className="relative p-2.5 rounded-xl text-slate-700 hover:bg-slate-100 border border-slate-200 transition-colors"
              aria-label="ตะกร้าสินค้า"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-red-600 text-white text-[11px] font-bold w-5 h-5 rounded-full flex items-center justify-center shadow-xs animate-bounce">
                  {cartCount}
                </span>
              )}
            </button>

            {/* User Profile Badge */}
            <div 
              onClick={() => onSelectTab('membership')}
              className={`flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-xl border cursor-pointer transition-all ${
                user.isRoyal 
                  ? 'bg-amber-50 border-amber-300 text-amber-900 shadow-xs' 
                  : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <div className="relative">
                <img 
                  src={user.avatar} 
                  alt={user.name} 
                  className="w-7 h-7 rounded-full object-cover border border-amber-400"
                />
                {user.isRoyal && (
                  <Crown className="w-3.5 h-3.5 text-amber-500 absolute -top-1.5 -right-1.5 fill-amber-400 drop-shadow" />
                )}
              </div>
              <div className="text-left hidden md:block leading-tight">
                <div className="text-xs font-bold flex items-center gap-1">
                  <span>{user.name}</span>
                  {user.isRoyal && <span className="text-[10px] text-amber-600 font-extrabold">👑 VIP</span>}
                </div>
                <div className="text-[10px] text-slate-500">
                  {user.isRoyal ? 'Royal Member • โหวต 2x' : 'สมาชิกทั่วไป'}
                </div>
              </div>
            </div>

            {/* Logout Button */}
            <button
              id="header-btn-logout"
              onClick={onLogout}
              className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 border border-slate-200 transition-colors"
              title="ออกจากระบบ เพื่อเข้าสู่หน้าสมัครสมาชิก / ล็อกอินใหม่"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 5 Primary Navigation Tabs */}
        <nav className="flex items-center space-x-1 sm:space-x-2 overflow-x-auto scrollbar-none py-2 border-t border-slate-100">
          <button
            id="nav-tab-ranking"
            onClick={() => onSelectTab('ranking')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-semibold transition-all shrink-0 ${
              currentTab === 'ranking'
                ? 'bg-orange-600 text-white shadow-sm shadow-orange-600/30'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Trophy className="w-4 h-4" />
            <span>1. ระบบ Ranking & Top 20</span>
          </button>

          <button
            id="nav-tab-restaurants"
            onClick={() => onSelectTab('restaurants')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-semibold transition-all shrink-0 ${
              currentTab === 'restaurants'
                ? 'bg-orange-600 text-white shadow-sm shadow-orange-600/30'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <MapPin className="w-4 h-4" />
            <span>2. ร้านอาหารทั่วไทย & SME</span>
            <span className="bg-amber-500/20 text-amber-800 text-[10px] px-1.5 py-0.5 rounded-full font-bold">
              77 จังหวัด
            </span>
          </button>

          <button
            id="nav-tab-merch"
            onClick={() => onSelectTab('merch')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-semibold transition-all shrink-0 ${
              currentTab === 'merch'
                ? 'bg-orange-600 text-white shadow-sm shadow-orange-600/30'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>3. สินค้า Merch</span>
            {user.isRoyal && (
              <span className="bg-amber-400 text-amber-950 text-[10px] px-1.5 py-0.5 rounded-full font-bold">
                ลด 15%
              </span>
            )}
          </button>

          <button
            id="nav-tab-forum"
            onClick={() => onSelectTab('forum')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-semibold transition-all shrink-0 ${
              currentTab === 'forum'
                ? 'bg-orange-600 text-white shadow-sm shadow-orange-600/30'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>4. กระทู้นักชิม</span>
          </button>

          <button
            id="nav-tab-membership"
            onClick={() => onSelectTab('membership')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-semibold transition-all shrink-0 ${
              currentTab === 'membership'
                ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-sm shadow-amber-500/30'
                : 'text-amber-800 bg-amber-50/70 hover:bg-amber-100'
            }`}
          >
            <Crown className="w-4 h-4 text-amber-500 fill-amber-300" />
            <span>5. ระบบเมมเบอร์ & Royal Vote</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
