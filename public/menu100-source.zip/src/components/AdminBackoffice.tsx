import React, { useState } from 'react';
import { FoodItem, RestaurantItem, MerchItem, UserProfile } from '../types';
import { 
  LayoutDashboard, 
  Utensils, 
  Store, 
  ShoppingBag, 
  Sliders, 
  Plus, 
  Edit3, 
  Trash2, 
  TrendingUp, 
  TrendingDown, 
  Save, 
  X, 
  Check, 
  ExternalLink, 
  Star, 
  ShieldCheck, 
  Crown, 
  Sparkles, 
  Search, 
  RotateCcw,
  Users,
  Award,
  DollarSign,
  Image,
  Flame,
  AlertCircle,
  Download
} from 'lucide-react';

interface AdminBackofficeProps {
  foods: FoodItem[];
  onUpdateFoods: (newFoods: FoodItem[]) => void;
  restaurants: RestaurantItem[];
  onUpdateRestaurants: (newRestaurants: RestaurantItem[]) => void;
  merchList: MerchItem[];
  onUpdateMerch: (newMerch: MerchItem[]) => void;
  onSwitchToClient: () => void;
  user: UserProfile;
}

export const AdminBackoffice: React.FC<AdminBackofficeProps> = ({
  foods,
  onUpdateFoods,
  restaurants,
  onUpdateRestaurants,
  merchList,
  onUpdateMerch,
  onSwitchToClient,
  user,
}) => {
  const [activeAdminTab, setActiveAdminTab] = useState<'foods' | 'restaurants' | 'merch' | 'analytics' | 'season'>('foods');
  const [searchFoodQuery, setSearchFoodQuery] = useState('');
  const [editingFood, setEditingFood] = useState<FoodItem | null>(null);
  const [isAddingFood, setIsAddingFood] = useState(false);

  // New Food Form State
  const [newFoodName, setNewFoodName] = useState('');
  const [newFoodNameEn, setNewFoodNameEn] = useState('');
  const [newFoodCategory, setNewFoodCategory] = useState<any>('single_dish');
  const [newFoodOrigin, setNewFoodOrigin] = useState('ไทย');
  const [newFoodImage, setNewFoodImage] = useState('');
  const [newFoodDesc, setNewFoodDesc] = useState('');
  const [newFoodCalories, setNewFoodCalories] = useState(450);
  const [newFoodFlavor, setNewFoodFlavor] = useState('กลมกล่อม, หอมเครื่องเทศ');
  const [newFoodRegularVotes, setNewFoodRegularVotes] = useState(100);
  const [newFoodRoyalVotes, setNewFoodRoyalVotes] = useState(25);

  // Notification Banner
  const [adminNotice, setAdminNotice] = useState<string | null>(null);

  const showNotice = (msg: string) => {
    setAdminNotice(msg);
    setTimeout(() => setAdminNotice(null), 3000);
  };

  // Preset food images for quick selection
  const PRESET_FOOD_IMAGES = [
    { name: 'ต้มยำกุ้ง', url: 'https://images.unsplash.com/photo-1548943487-a2e4e43b4853?auto=format&fit=crop&w=800&q=80' },
    { name: 'ผัดไทย', url: 'https://images.unsplash.com/photo-1559847844-5315695dadae?auto=format&fit=crop&w=800&q=80' },
    { name: 'ราเมน', url: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=800&q=80' },
    { name: 'สเต๊กเนื้อ', url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80' },
    { name: 'พิซซ่า', url: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80' },
    { name: 'ของหวาน / บิงซู', url: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=800&q=80' },
  ];

  // Adjust votes directly from dashboard
  const handleAdjustVotes = (foodId: string, type: 'regular' | 'royal', amount: number) => {
    const updated = foods.map((f) => {
      if (f.id === foodId) {
        if (type === 'regular') {
          return { ...f, regularVotes: Math.max(0, f.regularVotes + amount) };
        } else {
          return { ...f, royalVotes: Math.max(0, f.royalVotes + amount) };
        }
      }
      return f;
    });

    // Re-rank items according to total weighted score
    updated.sort((a, b) => (b.regularVotes + b.royalVotes * 2) - (a.regularVotes + a.royalVotes * 2));
    const reRanked = updated.map((item, idx) => ({ ...item, rank: idx + 1 }));

    onUpdateFoods(reRanked);
    showNotice(`ปรับคะแนน ${type === 'royal' ? 'Royal Vote' : 'คะแนนปกติ'} เรียบร้อยแล้ว`);
  };

  // Delete food item
  const handleDeleteFood = (foodId: string) => {
    if (confirm('คุณแน่ใจหรือไม่ว่าต้องการลบเมนูนี้ออกจากระบบ menu100?')) {
      const filtered = foods.filter((f) => f.id !== foodId);
      onUpdateFoods(filtered);
      showNotice('ลบเมนูเรียบร้อยแล้ว');
    }
  };

  // Save food changes
  const handleSaveEditFood = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingFood) return;

    const updated = foods.map((f) => (f.id === editingFood.id ? editingFood : f));
    updated.sort((a, b) => (b.regularVotes + b.royalVotes * 2) - (a.regularVotes + a.royalVotes * 2));
    const reRanked = updated.map((item, idx) => ({ ...item, rank: idx + 1 }));

    onUpdateFoods(reRanked);
    setEditingFood(null);
    showNotice(`บันทึกการแก้ไขเมนู "${editingFood.name}" สำเร็จ!`);
  };

  // Add new food
  const handleCreateFood = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFoodName.trim()) return;

    const newId = `food-${Date.now()}`;
    const newFood: FoodItem = {
      id: newId,
      name: newFoodName,
      nameEn: newFoodNameEn || newFoodName,
      category: newFoodCategory,
      origin: newFoodOrigin,
      countryCode: 'TH',
      image: newFoodImage || PRESET_FOOD_IMAGES[0].url,
      description: newFoodDesc || 'เมนูอาหารแนะนำประจำระบบ menu100 คัดสรรโดยแอดมิน',
      tags: ['เมนูใหม่', 'menu100'],
      regularVotes: Number(newFoodRegularVotes) || 0,
      royalVotes: Number(newFoodRoyalVotes) || 0,
      rank: foods.length + 1,
      calories: Number(newFoodCalories) || 400,
      flavorProfile: newFoodFlavor.split(',').map((s) => s.trim()).filter(Boolean),
    };

    const newFoods = [newFood, ...foods];
    newFoods.sort((a, b) => (b.regularVotes + b.royalVotes * 2) - (a.regularVotes + a.royalVotes * 2));
    const reRanked = newFoods.map((item, idx) => ({ ...item, rank: idx + 1 }));

    onUpdateFoods(reRanked);
    setIsAddingFood(false);
    setNewFoodName('');
    setNewFoodNameEn('');
    setNewFoodImage('');
    setNewFoodDesc('');
    showNotice(`เพิ่มเมนู "${newFood.name}" เข้าสู่ระบบเรียบร้อยแล้ว!`);
  };

  // Adjust Restaurant Verify Stars
  const handleUpdateRestaurantStars = (restId: string, stars: 1 | 2 | 3 | 4 | 5) => {
    const updated = restaurants.map((r) => (r.id === restId ? { ...r, verifiedStars: stars } : r));
    onUpdateRestaurants(updated);
    showNotice(`ปรับระดับ Verify เป็น ${stars} ดาว เรียบร้อยแล้ว`);
  };

  // Toggle Restaurant League Tier
  const handleUpdateRestaurantLeague = (restId: string, league: 'provincial' | 'regional' | 'national') => {
    const updated = restaurants.map((r) => (r.id === restId ? { ...r, leagueTier: league } : r));
    onUpdateRestaurants(updated);
    showNotice(`ปรับระดับลีกเป็น: ${league}`);
  };

  // Toggle Restaurant SME Status
  const handleToggleSme = (restId: string) => {
    const updated = restaurants.map((r) => (r.id === restId ? { ...r, isSme: !r.isSme } : r));
    onUpdateRestaurants(updated);
    showNotice('อัปเดตสถานะโครงการสนับสนุน SME แล้ว');
  };

  // Reset Season Votes
  const handleResetSeason = () => {
    if (confirm('คำเตือน: คุณต้องการรีเซ็ตคะแนนโหวตรอบ 2 เดือนเพื่อเริ่มซีซันใหม่หรือไม่? (คะแนนจะถูกปรับเป็นศูนย์)')) {
      const reset = foods.map((f) => ({ ...f, regularVotes: 0, royalVotes: 0 }));
      onUpdateFoods(reset);
      showNotice('⚡ รีเซ็ตคะแนนโหวตซีซันใหม่เรียบร้อยแล้ว');
    }
  };

  // Filter foods in admin
  const filteredFoods = foods.filter((f) => {
    if (!searchFoodQuery.trim()) return true;
    const q = searchFoodQuery.toLowerCase();
    return f.name.toLowerCase().includes(q) || f.nameEn.toLowerCase().includes(q) || f.origin.toLowerCase().includes(q);
  });

  const totalRegularVotes = foods.reduce((sum, f) => sum + f.regularVotes, 0);
  const totalRoyalVotes = foods.reduce((sum, f) => sum + f.royalVotes, 0);

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans">
      {/* Top Backoffice Navigation Bar */}
      <header className="bg-slate-950 border-b border-slate-800 sticky top-0 z-40 px-4 sm:px-6 py-3">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center font-black text-white text-base shadow-lg shadow-orange-500/20">
              m100
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-black tracking-tight text-white">
                  menu100 BACKOFFICE
                </h1>
                <span className="bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold px-2 py-0.5 rounded-md">
                  ADMIN CONTROL CENTER
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                ระบบจัดการหลังบ้าน • อัปเดตเมนู • แก้ไขรูปภาพ & ชื่อ • ปรับคะแนนโหวต • ตรวจสอบ Verify ร้านค้า
              </p>
            </div>
          </div>

          {/* Quick Action: Return to Public Site and Download ZIP */}
          <div className="flex items-center gap-2.5">
            <div className="text-right hidden md:block">
              <span className="text-[10px] text-slate-400 block">ผู้ดูแลระบบที่กำลังเข้าสู่ระบบ</span>
              <span className="text-xs font-bold text-amber-300">{user.name} (Admin)</span>
            </div>

            <a
              id="admin-btn-download-project-zip"
              href="/menu100-source.zip"
              download="menu100-source.zip"
              className="py-2 px-3 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs flex items-center gap-1.5 transition-colors border border-emerald-500/40 shadow-xs"
              title="ดาวน์โหลดไฟล์โปรเจกต์ทั้งหมดเป็น .ZIP เพื่อนำไปใส่ GitHub"
            >
              <Download className="w-4 h-4" />
              <span>📥 โหลดไฟล์โปรเจกต์ (.ZIP)</span>
            </a>

            <button
              id="admin-switch-to-public-site-btn"
              onClick={onSwitchToClient}
              className="py-2 px-4 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-bold text-xs shadow-md shadow-orange-500/20 flex items-center gap-2 transition-transform hover:scale-102"
            >
              <ExternalLink className="w-4 h-4" />
              <span>🌐 ดูหน้าเว็บหลัก (Public Site)</span>
            </button>
          </div>
        </div>
      </header>

      {/* Notice Banner */}
      {adminNotice && (
        <div className="bg-gradient-to-r from-amber-500 to-orange-500 text-white text-xs sm:text-sm font-bold py-2.5 px-4 text-center shadow-lg animate-in fade-in flex items-center justify-center gap-2">
          <Sparkles className="w-4 h-4" />
          <span>{adminNotice}</span>
        </div>
      )}

      {/* Main Container */}
      <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6 flex-1">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-800">
          <button
            id="admin-tab-foods"
            onClick={() => setActiveAdminTab('foods')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold shrink-0 transition-all flex items-center gap-2 ${
              activeAdminTab === 'foods'
                ? 'bg-orange-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Utensils className="w-4 h-4" />
            <span>1. จัดการเมนูอาหาร & ปรับคะแนน ({foods.length})</span>
          </button>

          <button
            id="admin-tab-restaurants"
            onClick={() => setActiveAdminTab('restaurants')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold shrink-0 transition-all flex items-center gap-2 ${
              activeAdminTab === 'restaurants'
                ? 'bg-orange-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Store className="w-4 h-4" />
            <span>2. ตรวจสอบ Verify ร้านอาหาร ({restaurants.length})</span>
          </button>

          <button
            id="admin-tab-merch"
            onClick={() => setActiveAdminTab('merch')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold shrink-0 transition-all flex items-center gap-2 ${
              activeAdminTab === 'merch'
                ? 'bg-orange-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>3. จัดการสินค้า Merch ({merchList.length})</span>
          </button>

          <button
            id="admin-tab-analytics"
            onClick={() => setActiveAdminTab('analytics')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold shrink-0 transition-all flex items-center gap-2 ${
              activeAdminTab === 'analytics'
                ? 'bg-orange-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>4. สถิติรวม & กราฟภาพรวม</span>
          </button>

          <button
            id="admin-tab-season"
            onClick={() => setActiveAdminTab('season')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold shrink-0 transition-all flex items-center gap-2 ${
              activeAdminTab === 'season'
                ? 'bg-orange-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <RotateCcw className="w-4 h-4" />
            <span>5. รีเซ็ตรอบ 2 เดือน & ตั้งค่า</span>
          </button>
        </div>

        {/* ================= TAB 1: จัดการเมนูอาหาร & ปรับคะแนนโหวต ================= */}
        {activeAdminTab === 'foods' && (
          <div className="space-y-6">
            {/* Top Toolbar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-800/80 p-4 rounded-2xl border border-slate-700">
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="admin-food-search"
                  type="text"
                  placeholder="ค้นหาเมนูเพื่อแก้ไข, ปรับคะแนน หรือเปลี่ยนรูป..."
                  value={searchFoodQuery}
                  onChange={(e) => setSearchFoodQuery(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 text-xs bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>

              <button
                id="admin-add-food-btn"
                onClick={() => setIsAddingFood(true)}
                className="py-2 px-4 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-sm"
              >
                <Plus className="w-4 h-4" />
                <span>+ เพิ่มเมนูอาหารใหม่เข้าสู่ระบบ</span>
              </button>
            </div>

            {/* Food Items Table / Cards */}
            <div className="bg-slate-800/60 rounded-3xl border border-slate-700 overflow-hidden">
              <div className="p-4 border-b border-slate-700 flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Utensils className="w-4 h-4 text-orange-400" />
                  <span>รายการเมนูอาหารทั้งหมด ({filteredFoods.length} เมนู)</span>
                </h3>
                <span className="text-xs text-slate-400">
                  ระบบคำนวณอันดับอัตโนมัติตาม (General Votes + Royal Votes x 2)
                </span>
              </div>

              <div className="divide-y divide-slate-700/60">
                {filteredFoods.map((food) => {
                  const totalScore = food.regularVotes + food.royalVotes * 2;

                  return (
                    <div
                      key={food.id}
                      className="p-4 sm:p-5 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 hover:bg-slate-800/90 transition-colors"
                    >
                      {/* Left: Thumbnail, Rank, Name & Origin */}
                      <div className="flex items-center gap-3.5 flex-1">
                        <div className="relative w-16 h-16 rounded-2xl overflow-hidden shrink-0 border border-slate-600">
                          <img
                            src={food.image}
                            alt={food.name}
                            className="w-full h-full object-cover"
                          />
                          <span className="absolute bottom-0 inset-x-0 bg-black/80 text-[10px] text-center text-amber-400 font-black">
                            #{food.rank}
                          </span>
                        </div>

                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-bold text-white text-sm sm:text-base">
                              {food.name}
                            </h4>
                            <span className="text-xs text-slate-400 font-mono">({food.nameEn})</span>
                            <span className="text-[10px] bg-slate-700 text-slate-300 px-2 py-0.5 rounded-md">
                              {food.origin}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 line-clamp-1 mt-0.5">
                            {food.description}
                          </p>
                          <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
                            <span>แคลอรี: {food.calories} kcal</span>
                            <span>•</span>
                            <span className="text-amber-400 font-bold">
                              รสชาติ: {food.flavorProfile.join(', ')}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Middle: Vote Counters & Quick Adjust (+/-) */}
                      <div className="flex flex-wrap items-center gap-3 bg-slate-900/80 p-2.5 rounded-2xl border border-slate-700/80">
                        {/* Regular Votes Adjuster */}
                        <div className="text-center px-2">
                          <div className="text-[10px] text-slate-400 mb-0.5">คะแนนโหวตทั่วไป</div>
                          <div className="font-mono font-bold text-white text-xs">
                            {food.regularVotes.toLocaleString()}
                          </div>
                          <div className="flex items-center gap-1 mt-1">
                            <button
                              id={`admin-minus-reg-${food.id}`}
                              onClick={() => handleAdjustVotes(food.id, 'regular', -100)}
                              className="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-[10px] font-bold text-rose-400"
                              title="ลด 100 คะแนน"
                            >
                              -100
                            </button>
                            <button
                              id={`admin-plus-reg-${food.id}`}
                              onClick={() => handleAdjustVotes(food.id, 'regular', 100)}
                              className="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-[10px] font-bold text-emerald-400"
                              title="เพิ่ม 100 คะแนน"
                            >
                              +100
                            </button>
                            <button
                              onClick={() => handleAdjustVotes(food.id, 'regular', 1000)}
                              className="px-1.5 py-0.5 rounded bg-orange-600/30 hover:bg-orange-600 text-[10px] font-bold text-orange-300"
                              title="เพิ่ม 1,000 คะแนน"
                            >
                              +1k
                            </button>
                          </div>
                        </div>

                        <div className="w-px h-8 bg-slate-700" />

                        {/* Royal Votes Adjuster */}
                        <div className="text-center px-2">
                          <div className="text-[10px] text-amber-300 font-bold flex items-center justify-center gap-0.5 mb-0.5">
                            <Crown className="w-3 h-3 text-amber-400 fill-amber-400" />
                            <span>Royal Vote (x2)</span>
                          </div>
                          <div className="font-mono font-black text-amber-400 text-xs">
                            {food.royalVotes.toLocaleString()}
                          </div>
                          <div className="flex items-center gap-1 mt-1">
                            <button
                              id={`admin-minus-royal-${food.id}`}
                              onClick={() => handleAdjustVotes(food.id, 'royal', -50)}
                              className="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-[10px] font-bold text-rose-400"
                              title="ลด 50 คะแนน Royal"
                            >
                              -50
                            </button>
                            <button
                              id={`admin-plus-royal-${food.id}`}
                              onClick={() => handleAdjustVotes(food.id, 'royal', 50)}
                              className="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-[10px] font-bold text-emerald-400"
                              title="เพิ่ม 50 คะแนน Royal"
                            >
                              +50
                            </button>
                            <button
                              onClick={() => handleAdjustVotes(food.id, 'royal', 500)}
                              className="px-1.5 py-0.5 rounded bg-amber-500/30 hover:bg-amber-500 text-[10px] font-bold text-amber-200"
                              title="เพิ่ม 500 คะแนน Royal"
                            >
                              +500
                            </button>
                          </div>
                        </div>

                        <div className="w-px h-8 bg-slate-700" />

                        {/* Total Weighted Score */}
                        <div className="text-right px-2">
                          <div className="text-[10px] text-slate-400">คะแนนรวมถ่วงน้ำหนัก</div>
                          <div className="font-mono font-black text-sm text-orange-400">
                            {totalScore.toLocaleString()} pt
                          </div>
                        </div>
                      </div>

                      {/* Right: Edit & Delete Buttons */}
                      <div className="flex items-center gap-2 self-end lg:self-center">
                        <button
                          id={`admin-edit-food-btn-${food.id}`}
                          onClick={() => setEditingFood(food)}
                          className="py-2 px-3 rounded-xl bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
                        >
                          <Edit3 className="w-3.5 h-3.5 text-amber-400" />
                          <span>แก้ไข / เปลี่ยนรูป</span>
                        </button>

                        <button
                          id={`admin-delete-food-btn-${food.id}`}
                          onClick={() => handleDeleteFood(food.id)}
                          className="p-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 transition-colors"
                          title="ลบเมนูนี้"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 2: ตรวจสอบร้านอาหาร & ตราดาว VERIFY ================= */}
        {activeAdminTab === 'restaurants' && (
          <div className="space-y-6">
            <div className="bg-slate-800/80 p-5 rounded-3xl border border-slate-700 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-amber-400" />
                  <span>จัดการร้านอาหาร & พิจารณา Verify ดาว 1-5 ดาว</span>
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  ปรับระดับดาว เพิ่ม/ลดลำดับลีกการแข่งขัน (ระดับจังหวัด / ภูมิภาค / ประเทศ) และให้สิทธิ์ SME ท้องถิ่น
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {restaurants.map((rest) => (
                <div
                  key={rest.id}
                  className="bg-slate-800/60 p-5 rounded-3xl border border-slate-700 flex flex-col justify-between space-y-4 hover:border-slate-600 transition-colors"
                >
                  <div className="flex items-start gap-3.5">
                    <img
                      src={rest.image}
                      alt={rest.name}
                      className="w-20 h-20 rounded-2xl object-cover shrink-0 border border-slate-600"
                    />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className="font-bold text-white text-base">{rest.name}</h4>
                        <span className="text-[10px] bg-slate-700 text-amber-300 font-bold px-2 py-0.5 rounded-md">
                          จ.{rest.provinceName}
                        </span>
                      </div>
                      <p className="text-xs text-orange-400 font-medium">{rest.cuisine}</p>
                      <p className="text-xs text-slate-400 line-clamp-2 mt-1">{rest.description}</p>
                    </div>
                  </div>

                  {/* Controls: Stars, League, SME */}
                  <div className="bg-slate-900/80 p-3 rounded-2xl border border-slate-700/80 space-y-2.5 text-xs">
                    {/* Stars Selector */}
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 text-[11px]">ตราดาว Verify:</span>
                      <div className="flex items-center gap-1">
                        {([1, 2, 3, 4, 5] as const).map((num) => (
                          <button
                            key={num}
                            onClick={() => handleUpdateRestaurantStars(rest.id, num)}
                            className={`p-1 rounded-md transition-colors ${
                              rest.verifiedStars >= num ? 'text-amber-400' : 'text-slate-600 hover:text-slate-500'
                            }`}
                          >
                            <Star className="w-4 h-4 fill-current" />
                          </button>
                        ))}
                        <span className="text-amber-400 font-bold ml-1">({rest.verifiedStars} ดาว)</span>
                      </div>
                    </div>

                    {/* League Tier */}
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 text-[11px]">ลีกการแข่งขัน:</span>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleUpdateRestaurantLeague(rest.id, 'provincial')}
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            rest.leagueTier === 'provincial' ? 'bg-orange-600 text-white' : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          ลีกจังหวัด
                        </button>
                        <button
                          onClick={() => handleUpdateRestaurantLeague(rest.id, 'regional')}
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            rest.leagueTier === 'regional' ? 'bg-orange-600 text-white' : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          ลีกภูมิภาค
                        </button>
                        <button
                          onClick={() => handleUpdateRestaurantLeague(rest.id, 'national')}
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            rest.leagueTier === 'national' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          ลีกประเทศ 🏆
                        </button>
                      </div>
                    </div>

                    {/* SME Status */}
                    <div className="flex items-center justify-between pt-1 border-t border-slate-800">
                      <span className="text-slate-400 text-[11px]">สถานะร้าน SME ชุมชน:</span>
                      <button
                        onClick={() => handleToggleSme(rest.id)}
                        className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold transition-colors ${
                          rest.isSme
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {rest.isSme ? '✓ ผ่านเกณฑ์ SME' : 'ร้านทั่วไป'}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ================= TAB 3: จัดการสินค้า MERCH ================= */}
        {activeAdminTab === 'merch' && (
          <div className="space-y-6">
            <div className="bg-slate-800/80 p-5 rounded-3xl border border-slate-700">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-orange-400" />
                <span>จัดการสินค้า Official Merch ({merchList.length} รายการ)</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                แก้ไขราคา, ส่วนลดสมาชิก Royal, สต็อกสินค้า และภาพสินค้า
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {merchList.map((item) => (
                <div
                  key={item.id}
                  className="bg-slate-800/60 rounded-3xl overflow-hidden border border-slate-700 flex flex-col justify-between"
                >
                  <div className="h-44 overflow-hidden relative">
                    <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                    <span className="absolute top-3 right-3 bg-amber-400 text-slate-950 text-[10px] font-black px-2.5 py-0.5 rounded-full">
                      ลด Royal {item.royalDiscountPercent}%
                    </span>
                  </div>

                  <div className="p-4 space-y-3">
                    <div>
                      <h4 className="font-bold text-white text-sm">{item.name}</h4>
                      <p className="text-xs text-slate-400">{item.nameEn}</p>
                    </div>

                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-400">ราคาขาย:</span>
                      <span className="font-mono font-black text-amber-400 text-base">฿{item.price}</span>
                    </div>

                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-400">สถานะสต็อก:</span>
                      <span className="text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded">
                        พร้อมจำหน่าย (In Stock)
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ================= TAB 4: สถิติรวม & ANALYTICS ================= */}
        {activeAdminTab === 'analytics' && (
          <div className="space-y-6">
            {/* Stat Badges */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-slate-800/80 p-5 rounded-3xl border border-slate-700 space-y-1">
                <span className="text-xs text-slate-400 flex items-center gap-1.5">
                  <Utensils className="w-4 h-4 text-orange-400" />
                  เมนูในระบบทั้งหมด
                </span>
                <div className="text-2xl font-black text-white">{foods.length} เมนู</div>
                <p className="text-[11px] text-slate-500">ติด Top 20 โลก: 20 รายการ</p>
              </div>

              <div className="bg-slate-800/80 p-5 rounded-3xl border border-slate-700 space-y-1">
                <span className="text-xs text-slate-400 flex items-center gap-1.5">
                  <TrendingUp className="w-4 h-4 text-emerald-400" />
                  คะแนนโหวตคนทั่วไป
                </span>
                <div className="text-2xl font-black text-white">{totalRegularVotes.toLocaleString()} โหวต</div>
                <p className="text-[11px] text-emerald-400">ซีซัน 5 Active</p>
              </div>

              <div className="bg-slate-800/80 p-5 rounded-3xl border border-slate-700 space-y-1">
                <span className="text-xs text-amber-300 flex items-center gap-1.5">
                  <Crown className="w-4 h-4 text-amber-400 fill-amber-400" />
                  Royal Votes (x2)
                </span>
                <div className="text-2xl font-black text-amber-400">{totalRoyalVotes.toLocaleString()} โหวต</div>
                <p className="text-[11px] text-amber-400/80">คะแนนถ่วงน้ำหนักพิเศษ</p>
              </div>

              <div className="bg-slate-800/80 p-5 rounded-3xl border border-slate-700 space-y-1">
                <span className="text-xs text-slate-400 flex items-center gap-1.5">
                  <Store className="w-4 h-4 text-blue-400" />
                  ร้านอาหารผ่านการ Verify
                </span>
                <div className="text-2xl font-black text-white">{restaurants.length} ร้าน</div>
                <p className="text-[11px] text-blue-400">ครอบคลุม 77 จังหวัด</p>
              </div>
            </div>

            {/* Top 5 Podium Ranking in Admin */}
            <div className="bg-slate-800/80 p-6 rounded-3xl border border-slate-700 space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-400" />
                <span>5 อันดับผู้นำผลโหวตล่าสุด (Real-time Leaderboard)</span>
              </h3>

              <div className="space-y-2">
                {foods.slice(0, 5).map((food, idx) => {
                  const totalScore = food.regularVotes + food.royalVotes * 2;
                  return (
                    <div
                      key={food.id}
                      className="p-3 bg-slate-900 rounded-2xl flex items-center justify-between gap-3 border border-slate-700/60"
                    >
                      <div className="flex items-center gap-3">
                        <span className={`w-7 h-7 rounded-xl flex items-center justify-center font-black text-xs ${
                          idx === 0 ? 'bg-amber-400 text-slate-950' :
                          idx === 1 ? 'bg-slate-300 text-slate-950' :
                          idx === 2 ? 'bg-amber-700 text-white' : 'bg-slate-800 text-slate-400'
                        }`}>
                          {idx + 1}
                        </span>
                        <span className="font-bold text-white text-xs sm:text-sm">{food.name}</span>
                        <span className="text-[10px] text-slate-400 font-mono">({food.origin})</span>
                      </div>

                      <div className="flex items-center gap-4 text-xs">
                        <span className="text-slate-400 hidden sm:inline">👥 {food.regularVotes.toLocaleString()}</span>
                        <span className="text-amber-400 font-bold">👑 {food.royalVotes.toLocaleString()}</span>
                        <span className="font-mono font-black text-orange-400">{totalScore.toLocaleString()} pt</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 5: รีเซ็ตรอบ 2 เดือน & ตั้งค่าซีซัน ================= */}
        {activeAdminTab === 'season' && (
          <div className="space-y-6 max-w-2xl">
            <div className="bg-slate-800/80 p-6 rounded-3xl border border-slate-700 space-y-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <RotateCcw className="w-5 h-5 text-orange-400" />
                <span>การบริหารรอบการโหวต & ซีซัน (ทุก 2 เดือน)</span>
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                ตามเกณฑ์ของ menu100 อันดับอาหาร Top 20 โลก จะมีการแข่งขันในแต่ละรอบเป็นเวลา 2 เดือน เมื่อสิ้นสุดรอบ แอดมินสามารถกดรีเซ็ตเพื่อเริ่มเปิดรับคะแนนใหม่ในซีซันถัดไปได้ทันที
              </p>

              <div className="p-4 bg-slate-900 rounded-2xl border border-slate-700 space-y-2 text-xs">
                <div className="flex justify-between text-slate-300">
                  <span>ซีซันปัจจุบัน:</span>
                  <span className="font-bold text-amber-400">Season 5 (มีนาคม - เมษายน 2026)</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>สถานะการคำนวณคะแนน:</span>
                  <span className="font-bold text-emerald-400">ปกติ (เปิดรับคะแนนโหวต)</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>รอบรีเซ็ตถัดไป:</span>
                  <span className="font-bold text-white">อีก 24 วัน</span>
                </div>
              </div>

              <div className="pt-2">
                <button
                  id="admin-reset-season-btn"
                  onClick={handleResetSeason}
                  className="w-full py-3 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors shadow-lg shadow-rose-600/30"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>รีเซ็ตคะแนนโหวตรอบ 2 เดือน (Reset Season Votes)</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Full Food Edit Modal */}
      {editingFood && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs overflow-y-auto">
          <div 
            className="w-full max-w-lg bg-slate-900 text-white rounded-3xl overflow-hidden shadow-2xl border border-slate-700 my-8"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="bg-slate-950 p-5 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-orange-400" />
                <h3 className="text-base font-bold">แก้ไขข้อมูลเมนู: {editingFood.name}</h3>
              </div>
              <button
                onClick={() => setEditingFood(null)}
                className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEditFood} className="p-6 space-y-4 text-xs">
              {/* Image Preview & URL */}
              <div>
                <label className="block font-bold text-slate-300 mb-1">
                  รูปภาพเมนูอาหาร (Image URL)
                </label>
                <div className="flex items-center gap-3">
                  <img
                    src={editingFood.image}
                    alt="Preview"
                    className="w-16 h-16 rounded-2xl object-cover border border-slate-700 shrink-0"
                  />
                  <input
                    id="admin-edit-food-image"
                    type="url"
                    value={editingFood.image}
                    onChange={(e) => setEditingFood({ ...editingFood, image: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>

                {/* Preset image selector */}
                <div className="mt-2">
                  <span className="text-[10px] text-slate-400 block mb-1">หรือเลือกจากรูปพร้อมใช้:</span>
                  <div className="flex gap-1.5 overflow-x-auto pb-1">
                    {PRESET_FOOD_IMAGES.map((preset, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setEditingFood({ ...editingFood, image: preset.url })}
                        className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[10px] text-slate-300 shrink-0 border border-slate-700"
                      >
                        {preset.name}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Name TH and EN */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">ชื่อเมนู (ภาษาไทย) *</label>
                  <input
                    id="admin-edit-food-name-th"
                    type="text"
                    required
                    value={editingFood.name}
                    onChange={(e) => setEditingFood({ ...editingFood, name: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">ชื่อเมนู (English)</label>
                  <input
                    id="admin-edit-food-name-en"
                    type="text"
                    value={editingFood.nameEn}
                    onChange={(e) => setEditingFood({ ...editingFood, nameEn: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
              </div>

              {/* Origin & Calories */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">ประเทศ / แหล่งกำเนิด</label>
                  <input
                    type="text"
                    value={editingFood.origin}
                    onChange={(e) => setEditingFood({ ...editingFood, origin: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">แคลอรี (kcal)</label>
                  <input
                    type="number"
                    value={editingFood.calories || 400}
                    onChange={(e) => setEditingFood({ ...editingFood, calories: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block font-bold text-slate-300 mb-1">คำอธิบายเอกลักษณ์รสชาติ</label>
                <textarea
                  rows={3}
                  value={editingFood.description}
                  onChange={(e) => setEditingFood({ ...editingFood, description: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500 resize-none"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingFood(null)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:bg-slate-800 font-bold"
                >
                  ยกเลิก
                </button>
                <button
                  id="admin-save-food-changes-btn"
                  type="submit"
                  className="px-6 py-2 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold flex items-center gap-1.5 shadow-md"
                >
                  <Save className="w-4 h-4" />
                  <span>บันทึกการเปลี่ยนแปลง</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add New Food Modal */}
      {isAddingFood && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs overflow-y-auto">
          <div 
            className="w-full max-w-lg bg-slate-900 text-white rounded-3xl overflow-hidden shadow-2xl border border-slate-700 my-8"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="bg-slate-950 p-5 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Plus className="w-5 h-5 text-orange-400" />
                <h3 className="text-base font-bold">เพิ่มเมนูอาหารใหม่เข้าสู่ระบบ</h3>
              </div>
              <button
                onClick={() => setIsAddingFood(false)}
                className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateFood} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">ชื่อเมนู (ภาษาไทย) *</label>
                  <input
                    id="admin-new-food-name-th"
                    type="text"
                    required
                    placeholder="เช่น ข้าวซอยไก่แม่สาย"
                    value={newFoodName}
                    onChange={(e) => setNewFoodName(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">ชื่อเมนู (English)</label>
                  <input
                    type="text"
                    placeholder="e.g. Northern Thai Khao Soi"
                    value={newFoodNameEn}
                    onChange={(e) => setNewFoodNameEn(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">หมวดหมู่อาหาร</label>
                  <select
                    value={newFoodCategory}
                    onChange={(e) => setNewFoodCategory(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  >
                    <option value="single_dish">จานเดียว & ข้าว/เส้น</option>
                    <option value="soup_curry">ต้ม & แกง</option>
                    <option value="stirfry_fry">ผัด & ทอด</option>
                    <option value="street_food">สตรีทฟู้ด</option>
                    <option value="dessert_cafe">ของหวาน & เครื่องดื่ม</option>
                    <option value="international">อาหารนานาชาติ</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">ประเทศ / แหล่งกำเนิด</label>
                  <input
                    type="text"
                    placeholder="เช่น ไทย, ญี่ปุ่น, อิตาลี"
                    value={newFoodOrigin}
                    onChange={(e) => setNewFoodOrigin(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">URL รูปภาพ</label>
                <input
                  id="admin-new-food-image"
                  type="url"
                  placeholder="https://images.unsplash.com/..."
                  value={newFoodImage}
                  onChange={(e) => setNewFoodImage(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                />

                <div className="mt-1.5 flex gap-1.5 overflow-x-auto pb-1">
                  {PRESET_FOOD_IMAGES.map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setNewFoodImage(preset.url)}
                      className="px-2 py-0.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-[10px] text-slate-300 shrink-0 border border-slate-700"
                    >
                      {preset.name}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">คะแนนโหวตตั้งต้น (General)</label>
                  <input
                    type="number"
                    value={newFoodRegularVotes}
                    onChange={(e) => setNewFoodRegularVotes(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">คะแนน Royal Vote ตั้งต้น</label>
                  <input
                    type="number"
                    value={newFoodRoyalVotes}
                    onChange={(e) => setNewFoodRoyalVotes(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">คำอธิบายเมนู</label>
                <textarea
                  rows={2}
                  placeholder="บอกเล่าเอกลักษณ์ รสชาติเด่น วัตถุดิบพิเศษ..."
                  value={newFoodDesc}
                  onChange={(e) => setNewFoodDesc(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddingFood(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:bg-slate-800 font-bold"
                >
                  ยกเลิก
                </button>
                <button
                  id="admin-submit-new-food-btn"
                  type="submit"
                  className="px-6 py-2 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold flex items-center gap-1.5 shadow-md"
                >
                  <Check className="w-4 h-4" />
                  <span>เพิ่มเมนูเข้าสู่ระบบทันที</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
