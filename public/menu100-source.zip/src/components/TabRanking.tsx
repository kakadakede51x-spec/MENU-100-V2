import React, { useState } from 'react';
import { FoodItem, FoodCategory, UserProfile } from '../types';
import { 
  Trophy, 
  Crown, 
  Flame, 
  Clock, 
  Search, 
  Globe2, 
  ChevronUp, 
  Sparkles, 
  Check, 
  ThumbsUp,
  Info,
  Calendar,
  Layers,
  Heart
} from 'lucide-react';

interface TabRankingProps {
  foods: FoodItem[];
  user: UserProfile;
  onVote: (foodId: string) => void;
  onSelectFoodDetail: (food: FoodItem) => void;
}

export const TabRanking: React.FC<TabRankingProps> = ({
  foods,
  user,
  onVote,
  onSelectFoodDetail,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<FoodCategory | 'global_top20'>('global_top20');
  const [searchQuery, setSearchQuery] = useState('');
  const [justVotedId, setJustVotedId] = useState<string | null>(null);

  // Filter foods based on category & search
  const filteredFoods = foods.filter((food) => {
    if (selectedCategory === 'global_top20' && !food.isGlobalTop20) {
      return false;
    }
    if (selectedCategory !== 'global_top20' && selectedCategory !== 'all' && food.category !== selectedCategory) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        food.name.toLowerCase().includes(q) ||
        food.nameEn.toLowerCase().includes(q) ||
        food.origin.toLowerCase().includes(q) ||
        food.tags.some((t) => t.toLowerCase().includes(q))
      );
    }
    return true;
  }).sort((a, b) => {
    // Total weighted score = regularVotes + (royalVotes * 2)
    const scoreA = a.regularVotes + a.royalVotes * 2;
    const scoreB = b.regularVotes + b.royalVotes * 2;
    return scoreB - scoreA;
  });

  const handleVoteClick = (foodId: string) => {
    onVote(foodId);
    setJustVotedId(foodId);
    setTimeout(() => setJustVotedId(null), 1500);
  };

  const topThree = filteredFoods.slice(0, 3);
  const remainingFoods = filteredFoods.slice(3);

  return (
    <div className="space-y-8 pb-16">
      {/* Hero Banner: Season 2-Month Reset & Royal Vote Concept */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-stone-900 to-amber-950 text-white p-6 sm:p-8 shadow-xl border border-amber-500/30">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-80 h-80 bg-orange-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 w-64 h-64 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-3 gap-6 items-center">
          <div className="lg:col-span-2 space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 border border-amber-400/40 text-amber-300 text-xs font-bold">
              <Trophy className="w-4 h-4 text-amber-400" />
              <span>menu100 OFFICIAL GLOBAL & REGIONAL FOOD RANKING</span>
            </div>
            
            <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-white">
              ระบบจัดอันดับเมนูอาหารยอดนิยม & <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-400">Top 20 ทั่วโลก</span>
            </h1>
            
            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              ร่วมโหวตเมนูในดวงใจได้ทุกหมวดหมู่! ผลคะแนนแยกชัดเจนระหว่าง <strong className="text-white">General Vote (โหวตคนธรรมดา)</strong> และ <strong className="text-amber-400">Royal Vote 👑 (โหวตจากสมาชิกสิทธิพิเศษ)</strong> โดยมีรอบรีเซ็ตเพื่อเฟ้นหาเมนูแชมเปี้ยนใหม่ทุกๆ 2 เดือน
            </p>

            <div className="flex flex-wrap gap-4 pt-2 text-xs">
              <div className="flex items-center gap-2 bg-white/10 px-3 py-1.5 rounded-xl border border-white/10">
                <Crown className="w-4 h-4 text-amber-400" />
                <span>Royal Vote: น้ำหนักคะแนน x2 + บันทึกตราประทับทอง</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 px-3 py-1.5 rounded-xl border border-white/10">
                <Globe2 className="w-4 h-4 text-emerald-400" />
                <span>คัดสรรเมนูยอดฮิตจากกว่า 50 สัญชาติ</span>
              </div>
            </div>
          </div>

          {/* 2-Month Season Reset Card */}
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/15 shadow-inner space-y-3 text-center">
            <div className="flex items-center justify-center gap-2 text-amber-300 text-xs font-bold">
              <Calendar className="w-4 h-4" />
              <span>รอบฤดูกาลปัจจุบัน: SEASON 5</span>
            </div>
            
            <div className="text-3xl font-black text-white tracking-wider font-mono">
              24 วัน : 14 ชม.
            </div>
            <p className="text-[11px] text-slate-300">
              รอบ 2 เดือนจะรีเซ็ตในวันที่ 31 ส.ค. 2026
            </p>

            {/* Progress bar */}
            <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden border border-white/20">
              <div className="bg-gradient-to-r from-amber-400 to-orange-500 h-full rounded-full w-[60%]" />
            </div>

            <div className="flex justify-between text-[10px] text-slate-400">
              <span>เริ่ม: 1 ก.ค. 2026</span>
              <span>จบซีซัน: 31 ส.ค. 2026</span>
            </div>
          </div>
        </div>
      </section>

      {/* Category Tabs & Search Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          <button
            id="ranking-cat-top20"
            onClick={() => setSelectedCategory('global_top20')}
            className={`px-4 py-2 rounded-xl text-xs font-bold shrink-0 transition-all flex items-center gap-1.5 ${
              selectedCategory === 'global_top20'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <Globe2 className="w-3.5 h-3.5" />
            <span>🌍 Top 20 ทั่วโลก</span>
          </button>

          <button
            id="ranking-cat-all"
            onClick={() => setSelectedCategory('all')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold shrink-0 transition-all ${
              selectedCategory === 'all'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            ทั้งหมด
          </button>

          <button
            id="ranking-cat-soup"
            onClick={() => setSelectedCategory('soup_curry')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold shrink-0 transition-all ${
              selectedCategory === 'soup_curry'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            🍲 ต้ม & แกง
          </button>

          <button
            id="ranking-cat-stirfry"
            onClick={() => setSelectedCategory('stirfry_fry')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold shrink-0 transition-all ${
              selectedCategory === 'stirfry_fry'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            🍳 ผัด & ทอด
          </button>

          <button
            id="ranking-cat-single"
            onClick={() => setSelectedCategory('single_dish')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold shrink-0 transition-all ${
              selectedCategory === 'single_dish'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            🍜 จานเดียว & เส้น
          </button>

          <button
            id="ranking-cat-street"
            onClick={() => setSelectedCategory('street_food')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold shrink-0 transition-all ${
              selectedCategory === 'street_food'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            🍢 สตรีทฟู้ด
          </button>

          <button
            id="ranking-cat-dessert"
            onClick={() => setSelectedCategory('dessert_cafe')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold shrink-0 transition-all ${
              selectedCategory === 'dessert_cafe'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            🍧 ของหวาน & คาเฟ่
          </button>

          <button
            id="ranking-cat-international"
            onClick={() => setSelectedCategory('international')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold shrink-0 transition-all ${
              selectedCategory === 'international'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            🍕 อาหารนานาชาติ
          </button>
        </div>

        {/* Search input */}
        <div className="relative w-full md:w-72 shrink-0">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            id="ranking-search-input"
            type="text"
            placeholder="ค้นหาชื่ออาหาร, สัญชาติ..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 shadow-2xs"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
            >
              ล้าง
            </button>
          )}
        </div>
      </div>

      {/* TOP 3 PODIUM (Rank #1, #2, #3) */}
      {topThree.length >= 3 && !searchQuery && (
        <section className="bg-gradient-to-b from-amber-50/50 to-white p-6 rounded-3xl border border-amber-200/80 shadow-xs">
          <div className="text-center mb-6">
            <h2 className="text-xl font-extrabold text-slate-900 flex items-center justify-center gap-2">
              <Trophy className="w-5 h-5 text-amber-500 fill-amber-400" />
              <span>โพเดียม 3 อันดับสูงสุดประจำรอบ (The Golden Trio)</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              คะแนนคำนวณจาก General Vote + (Royal Vote x2) แบบเรียลไทม์
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end max-w-5xl mx-auto">
            {/* #2 Silver (Left) */}
            <div className="order-2 md:order-1 bg-white rounded-2xl p-5 border-2 border-slate-300 shadow-sm relative flex flex-col items-center text-center">
              <div className="absolute -top-4 bg-slate-300 text-slate-800 text-xs font-black px-3 py-1 rounded-full shadow-xs flex items-center gap-1">
                🥈 อันดับ 2 (เหรียญเงิน)
              </div>
              <img
                src={topThree[1].image}
                alt={topThree[1].name}
                className="w-28 h-28 rounded-2xl object-cover shadow-md mt-3 mb-3 border-2 border-slate-200"
              />
              <span className="text-[11px] text-orange-600 font-bold bg-orange-50 px-2 py-0.5 rounded-md">
                {topThree[1].origin}
              </span>
              <h3 className="font-bold text-slate-900 text-sm mt-1.5 line-clamp-1">{topThree[1].name}</h3>
              <p className="text-[11px] text-slate-500 line-clamp-1">{topThree[1].nameEn}</p>

              {/* Vote Breakdown */}
              <div className="w-full my-3 p-2 bg-slate-50 rounded-xl text-xs space-y-1">
                <div className="flex justify-between text-slate-600 text-[11px]">
                  <span>👥 General:</span>
                  <span className="font-bold">{topThree[1].regularVotes.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-amber-800 text-[11px]">
                  <span className="flex items-center gap-1">👑 Royal:</span>
                  <span className="font-extrabold">{topThree[1].royalVotes.toLocaleString()}</span>
                </div>
              </div>

              <button
                id={`ranking-vote-btn-${topThree[1].id}`}
                onClick={() => handleVoteClick(topThree[1].id)}
                className={`w-full py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                  user.votedFoodIds.includes(topThree[1].id)
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : user.isRoyal
                    ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-xs hover:opacity-95'
                    : 'bg-orange-600 hover:bg-orange-700 text-white'
                }`}
              >
                {user.votedFoodIds.includes(topThree[1].id) ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>คุณโหวตแล้ว</span>
                  </>
                ) : (
                  <>
                    {user.isRoyal ? <Crown className="w-3.5 h-3.5" /> : <ThumbsUp className="w-3.5 h-3.5" />}
                    <span>{user.isRoyal ? 'Royal Vote (x2)' : 'กดโหวต'}</span>
                  </>
                )}
              </button>
            </div>

            {/* #1 Gold (Center - taller) */}
            <div className="order-1 md:order-2 bg-gradient-to-b from-amber-100/70 to-white rounded-3xl p-6 border-3 border-amber-400 shadow-lg relative flex flex-col items-center text-center -mt-4">
              <div className="absolute -top-5 bg-gradient-to-r from-amber-500 to-orange-500 text-white text-xs font-black px-4 py-1.5 rounded-full shadow-md flex items-center gap-1.5">
                <Crown className="w-4 h-4 fill-white" />
                <span>🥇 อันดับ 1 (แชมเปี้ยนประจำซีซัน)</span>
              </div>
              <img
                src={topThree[0].image}
                alt={topThree[0].name}
                className="w-36 h-36 rounded-2xl object-cover shadow-lg mt-4 mb-3 border-4 border-amber-400 ring-4 ring-amber-200/50"
              />
              <span className="text-xs text-orange-700 font-black bg-amber-200/70 px-2.5 py-0.5 rounded-md">
                {topThree[0].origin}
              </span>
              <h3 className="font-black text-slate-900 text-base mt-2">{topThree[0].name}</h3>
              <p className="text-xs text-slate-500">{topThree[0].nameEn}</p>
              <p className="text-xs text-slate-600 line-clamp-2 mt-1 px-2">{topThree[0].description}</p>

              {/* Vote Breakdown */}
              <div className="w-full my-3 p-3 bg-amber-50/80 rounded-2xl border border-amber-200 text-xs space-y-1.5">
                <div className="flex justify-between text-slate-700 text-xs">
                  <span>👥 General Vote:</span>
                  <span className="font-bold">{topThree[0].regularVotes.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-amber-900 text-xs font-bold">
                  <span className="flex items-center gap-1 text-amber-700">👑 Royal Vote:</span>
                  <span className="font-black text-amber-800">{topThree[0].royalVotes.toLocaleString()}</span>
                </div>
                <div className="flex justify-between border-t border-amber-200/80 pt-1 text-xs font-black text-orange-700">
                  <span>รวมคะแนนถ่วงน้ำหนัก:</span>
                  <span>{(topThree[0].regularVotes + topThree[0].royalVotes * 2).toLocaleString()} pt</span>
                </div>
              </div>

              <button
                id={`ranking-vote-btn-${topThree[0].id}`}
                onClick={() => handleVoteClick(topThree[0].id)}
                className={`w-full py-2.5 px-4 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all ${
                  user.votedFoodIds.includes(topThree[0].id)
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : user.isRoyal
                    ? 'bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 text-white shadow-md shadow-orange-500/30 hover:scale-102'
                    : 'bg-orange-600 hover:bg-orange-700 text-white shadow-md'
                }`}
              >
                {user.votedFoodIds.includes(topThree[0].id) ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>คุณโหวตแชมป์จานนี้แล้ว</span>
                  </>
                ) : (
                  <>
                    {user.isRoyal ? <Crown className="w-4 h-4" /> : <Flame className="w-4 h-4" />}
                    <span>{user.isRoyal ? 'โหวตให้แชมป์ (Royal x2 👑)' : 'โหวตให้แชมป์จานนี้'}</span>
                  </>
                )}
              </button>
            </div>

            {/* #3 Bronze (Right) */}
            <div className="order-3 bg-white rounded-2xl p-5 border-2 border-amber-700/40 shadow-sm relative flex flex-col items-center text-center">
              <div className="absolute -top-4 bg-amber-800 text-white text-xs font-black px-3 py-1 rounded-full shadow-xs flex items-center gap-1">
                🥉 อันดับ 3 (เหรียญทองแดง)
              </div>
              <img
                src={topThree[2].image}
                alt={topThree[2].name}
                className="w-28 h-28 rounded-2xl object-cover shadow-md mt-3 mb-3 border-2 border-amber-600/30"
              />
              <span className="text-[11px] text-orange-600 font-bold bg-orange-50 px-2 py-0.5 rounded-md">
                {topThree[2].origin}
              </span>
              <h3 className="font-bold text-slate-900 text-sm mt-1.5 line-clamp-1">{topThree[2].name}</h3>
              <p className="text-[11px] text-slate-500 line-clamp-1">{topThree[2].nameEn}</p>

              {/* Vote Breakdown */}
              <div className="w-full my-3 p-2 bg-slate-50 rounded-xl text-xs space-y-1">
                <div className="flex justify-between text-slate-600 text-[11px]">
                  <span>👥 General:</span>
                  <span className="font-bold">{topThree[2].regularVotes.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-amber-800 text-[11px]">
                  <span className="flex items-center gap-1">👑 Royal:</span>
                  <span className="font-extrabold">{topThree[2].royalVotes.toLocaleString()}</span>
                </div>
              </div>

              <button
                id={`ranking-vote-btn-${topThree[2].id}`}
                onClick={() => handleVoteClick(topThree[2].id)}
                className={`w-full py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                  user.votedFoodIds.includes(topThree[2].id)
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : user.isRoyal
                    ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-xs hover:opacity-95'
                    : 'bg-orange-600 hover:bg-orange-700 text-white'
                }`}
              >
                {user.votedFoodIds.includes(topThree[2].id) ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>คุณโหวตแล้ว</span>
                  </>
                ) : (
                  <>
                    {user.isRoyal ? <Crown className="w-3.5 h-3.5" /> : <ThumbsUp className="w-3.5 h-3.5" />}
                    <span>{user.isRoyal ? 'Royal Vote (x2)' : 'กดโหวต'}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </section>
      )}

      {/* Complete Rankings List Table / Cards */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Layers className="w-5 h-5 text-orange-600" />
            <span>
              ตารางอันดับเมนูอาหาร ({filteredFoods.length} รายการ)
            </span>
          </h3>
          <span className="text-xs text-slate-500">
            แสดงผลโหวตแยกตามคำสั่ง: Royal Vote 👑 vs General Vote 👥
          </span>
        </div>

        <div className="grid grid-cols-1 gap-3">
          {filteredFoods.map((food, index) => {
            const hasVoted = user.votedFoodIds.includes(food.id);
            const totalScore = food.regularVotes + food.royalVotes * 2;
            const rankDisplay = index + 1;

            return (
              <div
                key={food.id}
                className={`bg-white rounded-2xl p-4 border transition-all hover:shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                  hasVoted ? 'border-emerald-300 bg-emerald-50/20' : 'border-slate-200'
                }`}
              >
                {/* Left: Rank & Image & Info */}
                <div className="flex items-center gap-3 sm:gap-4 flex-1 min-w-0">
                  <div className="w-10 text-center shrink-0">
                    <span className={`text-base sm:text-lg font-black ${
                      rankDisplay === 1 ? 'text-amber-500' :
                      rankDisplay === 2 ? 'text-slate-400' :
                      rankDisplay === 3 ? 'text-amber-700' : 'text-slate-500'
                    }`}>
                      #{rankDisplay}
                    </span>
                  </div>

                  <img
                    src={food.image}
                    alt={food.name}
                    className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl object-cover shrink-0 border border-slate-200 cursor-pointer hover:opacity-90"
                    onClick={() => onSelectFoodDetail(food)}
                  />

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[10px] font-bold text-orange-700 bg-orange-50 px-2 py-0.5 rounded-md border border-orange-200">
                        {food.origin}
                      </span>
                      {food.isGlobalTop20 && (
                        <span className="text-[10px] font-extrabold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded-md border border-blue-200">
                          TOP 20 โลก
                        </span>
                      )}
                      {food.calories && (
                        <span className="text-[10px] text-slate-400">
                          {food.calories} kcal
                        </span>
                      )}
                    </div>

                    <h4 
                      onClick={() => onSelectFoodDetail(food)}
                      className="text-sm sm:text-base font-bold text-slate-900 truncate hover:text-orange-600 cursor-pointer mt-0.5"
                    >
                      {food.name}
                    </h4>
                    <p className="text-xs text-slate-500 truncate">{food.nameEn}</p>

                    <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                      {food.flavorProfile.slice(0, 2).map((flv, idx) => (
                        <span key={idx} className="text-[10px] text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded">
                          #{flv}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Right: Detailed Vote Breakdown & Vote Action */}
                <div className="flex items-center justify-between sm:justify-end gap-4 w-full sm:w-auto shrink-0 border-t sm:border-t-0 pt-3 sm:pt-0">
                  {/* Detailed Vote Counts Box */}
                  <div className="text-right text-xs">
                    <div className="flex items-center gap-2 justify-end">
                      <span className="text-slate-500 text-[11px]">👥 คนทั่วไป:</span>
                      <span className="font-bold text-slate-800">{food.regularVotes.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center gap-2 justify-end text-amber-800 font-semibold">
                      <span className="flex items-center gap-0.5 text-amber-600 text-[11px]">
                        <Crown className="w-3 h-3 inline" /> Royal:
                      </span>
                      <span className="font-extrabold text-amber-900">{food.royalVotes.toLocaleString()}</span>
                    </div>
                    <div className="text-[11px] text-orange-600 font-bold">
                      รวม: {totalScore.toLocaleString()} pt
                    </div>
                  </div>

                  {/* Vote button */}
                  <button
                    id={`ranking-table-vote-${food.id}`}
                    onClick={() => handleVoteClick(food.id)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shrink-0 ${
                      hasVoted
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : user.isRoyal
                        ? 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white shadow-xs'
                        : 'bg-orange-600 hover:bg-orange-700 text-white'
                    }`}
                  >
                    {hasVoted ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>โหวตแล้ว</span>
                      </>
                    ) : user.isRoyal ? (
                      <>
                        <Crown className="w-3.5 h-3.5 text-amber-200 fill-amber-200" />
                        <span>Royal Vote</span>
                      </>
                    ) : (
                      <>
                        <ThumbsUp className="w-3.5 h-3.5" />
                        <span>โหวต</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
