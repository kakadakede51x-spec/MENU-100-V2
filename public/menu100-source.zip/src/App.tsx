import React, { useState, useEffect } from 'react';
import { TabType, FoodItem, RestaurantItem, MerchItem, CartItem, UserProfile, ViewMode } from './types';
import { INITIAL_FOODS, MOCK_RESTAURANTS, MERCH_PRODUCTS } from './data/mockData';
import { Header } from './components/Header';
import { TabRanking } from './components/TabRanking';
import { TabRestaurants } from './components/TabRestaurants';
import { TabMerch } from './components/TabMerch';
import { TabForum } from './components/TabForum';
import { TabMembership } from './components/TabMembership';
import { FoodRouletteModal } from './components/FoodRouletteModal';
import { VerifyRequestModal } from './components/VerifyRequestModal';
import { CartDrawer } from './components/CartDrawer';
import { FoodDetailModal } from './components/FoodDetailModal';
import { AuthGateModal } from './components/AuthGateModal';
import { AdminBackoffice } from './components/AdminBackoffice';
import { 
  Trophy, 
  MapPin, 
  ShoppingBag, 
  MessageSquare, 
  Crown, 
  Heart, 
  Sparkles, 
  CheckCircle,
  ShieldCheck,
  Globe2,
  Dice5,
  Sliders
} from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<TabType>('ranking');
  const [viewMode, setViewMode] = useState<ViewMode>('client');

  // Authentication Gate State (Required on entrance)
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('menu100_auth_session') === 'true';
  });

  // Load / initialize persistent local storage
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('menu100_user');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* ignore */ }
    }
    return {
      id: 'usr-foodie-100',
      username: 'foodie_lover',
      name: 'คุณกานต์ นักชิมตัวจริง',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
      isRoyal: true,
      royalLevel: 'Diamond',
      role: 'admin',
      joinedDate: 'กันยายน 2026',
      votedFoodIds: [],
      bookmarkedRestaurantIds: [],
      royalVotesLeftThisMonth: 10,
    };
  });

  const [foods, setFoods] = useState<FoodItem[]>(() => {
    const saved = localStorage.getItem('menu100_foods');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* ignore */ }
    }
    return INITIAL_FOODS;
  });

  const [restaurants, setRestaurants] = useState<RestaurantItem[]>(() => {
    const saved = localStorage.getItem('menu100_restaurants');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* ignore */ }
    }
    return MOCK_RESTAURANTS;
  });

  const [merchList, setMerchList] = useState<MerchItem[]>(() => {
    const saved = localStorage.getItem('menu100_merch');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* ignore */ }
    }
    return MERCH_PRODUCTS;
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('menu100_cart');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* ignore */ }
    }
    return [];
  });


  // Modals state
  const [isRouletteOpen, setIsRouletteOpen] = useState(false);
  const [isVerifyModalOpen, setIsVerifyModalOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedFoodDetail, setSelectedFoodDetail] = useState<FoodItem | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync state to local storage
  useEffect(() => {
    localStorage.setItem('menu100_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('menu100_foods', JSON.stringify(foods));
  }, [foods]);

  useEffect(() => {
    localStorage.setItem('menu100_restaurants', JSON.stringify(restaurants));
  }, [restaurants]);

  useEffect(() => {
    localStorage.setItem('menu100_merch', JSON.stringify(merchList));
  }, [merchList]);

  useEffect(() => {
    localStorage.setItem('menu100_cart', JSON.stringify(cart));
  }, [cart]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Login / Register success handler
  const handleLoginSuccess = (newUser: UserProfile) => {
    setUser(newUser);
    setIsAuthenticated(true);
    localStorage.setItem('menu100_auth_session', 'true');
    showToast(`✓ ยินดีต้อนรับคุณ ${newUser.name} เข้าสู่ menu100!`);
  };

  // Logout handler
  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('menu100_auth_session');
    showToast('ออกจากระบบเรียบร้อยแล้ว คุณสามารถเข้าสู่ระบบหรือสมัครใหม่ได้');
  };

  // Toggle user Royal status

  const handleToggleRoyal = () => {
    setUser((prev) => {
      const updated = { ...prev, isRoyal: !prev.isRoyal };
      showToast(
        updated.isRoyal
          ? '👑 สลับเป็นสถานะ: ROYAL MEMBER แล้ว! (โหวตน้ำหนัก x2, ลด Merch 15%)'
          : 'สลับกลับเป็นสถานะ: สมาชิกทั่วไป เรียบร้อยแล้ว'
      );
      return updated;
    });
  };

  // Vote handler
  const handleVote = (foodId: string) => {
    const isAlreadyVoted = user.votedFoodIds.includes(foodId);

    if (isAlreadyVoted) {
      // Unvote
      setUser((prev) => ({
        ...prev,
        votedFoodIds: prev.votedFoodIds.filter((id) => id !== foodId),
      }));
      setFoods((prev) =>
        prev.map((f) => {
          if (f.id === foodId) {
            return user.isRoyal
              ? { ...f, royalVotes: Math.max(0, f.royalVotes - 1) }
              : { ...f, regularVotes: Math.max(0, f.regularVotes - 1) };
          }
          return f;
        })
      );
      showToast('ยกเลิกการโหวตเมนูนี้แล้ว');
    } else {
      // Vote
      setUser((prev) => ({
        ...prev,
        votedFoodIds: [...prev.votedFoodIds, foodId],
      }));
      setFoods((prev) =>
        prev.map((f) => {
          if (f.id === foodId) {
            return user.isRoyal
              ? { ...f, royalVotes: f.royalVotes + 1 }
              : { ...f, regularVotes: f.regularVotes + 1 };
          }
          return f;
        })
      );
      showToast(
        user.isRoyal
          ? '👑 ลงคะแนนแบบ ROYAL VOTE สำเร็จ! (นับแยกและถ่วงน้ำหนัก x2)'
          : 'ลงคะแนนโหวตสำเร็จ! ขอบคุณที่ร่วมส่งเสียงให้นักชิม'
      );
    }
  };

  // Cart operations
  const handleAddToCart = (merch: MerchItem, size?: string, color?: string) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.merch.id === merch.id);
      if (existing) {
        return prev.map((item) =>
          item.merch.id === merch.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { merch, quantity: 1, selectedSize: size, selectedColor: color }];
    });
  };

  const handleQuickBuy = (merch: MerchItem, size?: string, color?: string) => {
    handleAddToCart(merch, size, color);
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.merch.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveCartItem = (id: string) => {
    setCart((prev) => prev.filter((i) => i.merch.id !== id));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // Verify request handler
  const handleVerifySubmitSuccess = (data: any) => {
    const newRest: RestaurantItem = {
      id: `rest-${Date.now()}`,
      name: data.restaurantName,
      provinceId: data.provinceId,
      provinceName: data.provinceId,
      region: 'central',
      address: `จ.${data.provinceId} (อยู่ระหว่างการปักหมุด GPS)`,
      verifiedStars: 3,
      menu100Score: 90,
      isSme: data.isSme,
      isStreetFood: true,
      leagueTier: 'provincial',
      image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=900&q=80',
      cuisine: data.cuisine || 'อาหารไทยต้นตำรับ',
      priceRange: '฿฿',
      highlightDishes: data.highlightDishes ? data.highlightDishes.split(',') : ['เมนูเด็ดประจำร้าน'],
      openHours: '09:00 - 20:00 น.',
      phone: data.phone,
      reviewCount: 1,
      description: data.story || 'ร้านอาหารที่ยื่นขอรับการ Verify จาก menu100',
      rankInProvince: restaurants.length + 1,
    };

    setRestaurants([newRest, ...restaurants]);
    showToast(`✓ ยื่นขอ Verify สำเร็จ! ร้าน "${data.restaurantName}" ได้รับการพิจารณาเบื้องต้น ⭐⭐⭐ 3 ดาว`);
    setCurrentTab('restaurants');
  };

  // If admin backoffice mode is active, render dedicated backoffice portal
  if (viewMode === 'admin') {
    return (
      <AdminBackoffice
        foods={foods}
        onUpdateFoods={setFoods}
        restaurants={restaurants}
        onUpdateRestaurants={setRestaurants}
        merchList={merchList}
        onUpdateMerch={setMerchList}
        onSwitchToClient={() => setViewMode('client')}
        user={user}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-orange-500 selection:text-white">
      {/* Mandatory Entrance Auth Gate Modal if not logged in */}
      {!isAuthenticated && (
        <AuthGateModal onLoginSuccess={handleLoginSuccess} />
      )}

      {/* Header with Navigation and Quick Actions */}
      <Header
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        user={user}
        onToggleRoyal={handleToggleRoyal}
        cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenRoulette={() => setIsRouletteOpen(true)}
        onOpenVerifyModal={() => setIsVerifyModalOpen(true)}
        onOpenAdmin={() => setViewMode('admin')}
        onLogout={handleLogout}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {currentTab === 'ranking' && (
          <TabRanking
            foods={foods}
            user={user}
            onVote={handleVote}
            onSelectFoodDetail={setSelectedFoodDetail}
          />
        )}

        {currentTab === 'restaurants' && (
          <TabRestaurants
            restaurants={restaurants}
            onOpenVerifyModal={() => setIsVerifyModalOpen(true)}
          />
        )}

        {currentTab === 'merch' && (
          <TabMerch
            merchList={merchList}
            onAddToCart={handleAddToCart}
            onQuickBuy={handleQuickBuy}
            user={user}
          />
        )}

        {currentTab === 'forum' && (
          <TabForum user={user} />
        )}

        {currentTab === 'membership' && (
          <TabMembership
            user={user}
            onToggleRoyal={handleToggleRoyal}
            onSelectTab={setCurrentTab}
          />
        )}
      </main>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 max-w-md p-4 bg-slate-900 text-white rounded-2xl shadow-2xl border border-amber-400/40 text-xs sm:text-sm font-bold flex items-center gap-3 animate-in slide-in-from-bottom-5">
          <Sparkles className="w-5 h-5 text-amber-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Modals & Drawers */}
      <FoodRouletteModal
        isOpen={isRouletteOpen}
        onClose={() => setIsRouletteOpen(false)}
        foods={foods}
        onSelectFood={(food) => setSelectedFoodDetail(food)}
      />

      <VerifyRequestModal
        isOpen={isVerifyModalOpen}
        onClose={() => setIsVerifyModalOpen(false)}
        onSubmitSuccess={handleVerifySubmitSuccess}
      />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
        user={user}
      />

      <FoodDetailModal
        food={selectedFoodDetail}
        onClose={() => setSelectedFoodDetail(null)}
        user={user}
        onVote={handleVote}
      />

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-12 border-t border-slate-800 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 border-b border-slate-800 pb-6">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center text-white font-black text-base">
                m100
              </div>
              <div>
                <span className="text-white font-extrabold text-base">menu100 Thailand</span>
                <p className="text-[11px] text-slate-500">
                  ระบบจัดอันดับอาหารโลก • แผนที่ 77 จังหวัด • สินค้า Merch • ชุมชนนักชิม
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4 text-xs font-semibold">
              <button onClick={() => setCurrentTab('ranking')} className="hover:text-white">1. Ranking</button>
              <button onClick={() => setCurrentTab('restaurants')} className="hover:text-white">2. ร้านอาหารทั่วไทย</button>
              <button onClick={() => setCurrentTab('merch')} className="hover:text-white">3. Merch</button>
              <button onClick={() => setCurrentTab('forum')} className="hover:text-white">4. กระทู้</button>
              <button onClick={() => setCurrentTab('membership')} className="hover:text-white">5. Royal Member</button>
              <button onClick={() => setViewMode('admin')} className="text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1">
                <Sliders className="w-3.5 h-3.5" />
                <span>ระบบหลังบ้าน</span>
              </button>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-slate-500">
            <p>© 2026 menu100. All rights reserved. เว็บแนะนำเมนูอาหารและอันดับร้านเด็ดทั่วไทย</p>
            <p>รอบรีเซ็ต 2 เดือน (ทุกวันสิ้นเดือนคู่) • ผลโหวต Royal Vote x2 ถ่วงน้ำหนัก</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
